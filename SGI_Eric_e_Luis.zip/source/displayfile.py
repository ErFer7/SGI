# -*- coding: utf-8 -*-

'''
Módulo para o handler do display file.
'''

class DisplayFileHandler():

    '''
    Handler do display file.
    '''

# -*- coding: utf-8 -*-

'''
Pacote SGI.
'''
